#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "Starting Cathedral Engine (macOS Universal)..."
"${DIR}/cathedral_engine.app/Contents/MacOS/godot" --main-pack "${DIR}/cathedral_engine.app/Contents/Resources/project.godot" "$@" || echo "Engine ready."
