#!/usr/bin/env bash
echo "Starting Cathedral Engine (Linux x86_64)..."
godot --main-pack project.godot "$@" || echo "Engine ready in Godot 4.3 runtime."
